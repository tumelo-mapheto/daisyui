import{a as t}from"../chunks/entry.BHlVaH7u.js";export{t as start};
