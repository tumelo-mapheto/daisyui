import{a as t}from"../chunks/entry.Bnq0PbS8.js";export{t as start};
