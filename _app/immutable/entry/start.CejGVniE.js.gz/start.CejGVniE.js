import{a as t}from"../chunks/entry.DjZkpiE8.js";export{t as start};
