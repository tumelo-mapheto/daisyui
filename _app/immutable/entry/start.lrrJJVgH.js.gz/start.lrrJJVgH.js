import{a as t}from"../chunks/entry.S1pcJVHi.js";export{t as start};
