import{s as N,z as W,m as B,A as q,a as x,d as S,j as b,h as r,e as v,c as u,g as T,i as $,n as I,t as j,b as M,f as D,k as E,D as A,E as H}from"../chunks/scheduler.CmJ_ZkIC.js";import{S as G,i as Q,c as f,b as g,m as _,t as w,a as y,d as C}from"../chunks/index.BimWP6M-.js";import{g as U,a as z}from"../chunks/spread.CgU5AtxT.js";import{M as X}from"../chunks/mdsvex-components.BJMdTQ-M.js";import{p as Z,C as tt,a as k,r as L}from"../chunks/ClassTable.CGsA8fYh.js";import"../chunks/entry.DjZkpiE8.js";function et(d){let t,l='<div class="chat chat-start"><div class="chat-bubble">It&#39;s over Anakin, <br/>I have the high ground.</div></div> <div class="chat chat-end"><div class="chat-bubble">You underestimate my power!</div></div>';return{c(){t=v("div"),t.innerHTML=l,this.h()},l(e){t=u(e,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-xa4d6j"&&(t.innerHTML=l),this.h()},h(){$(t,"class","w-full")},m(e,i){b(e,t,i)},p:I,d(e){e&&r(t)}}}function at(d){let t,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-bubble">It's over Anakin, <br/>I have the high ground.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble">You underestimate my power!</div>
</div>`,e,i,c,n;return{c(){t=v("pre"),e=j(l),this.h()},l(a){t=u(a,"PRE",{slot:!0});var o=M(t);e=D(o,l),o.forEach(r),this.h()},h(){$(t,"slot","html")},m(a,o){b(a,t,o),E(t,e),c||(n=A(i=L.call(null,t,{to:d[0]})),c=!0)},p(a,o){i&&H(i.update)&&o&1&&i.update.call(null,{to:a[0]})},d(a){a&&r(t),c=!1,n()}}}function st(d){let t,l='<div class="chat chat-start"><div class="chat-image avatar"><div class="w-10 rounded-full"><img alt="Tailwind CSS chat bubble component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div> <div class="chat-bubble">It was said that you would, destroy the Sith, not join them.</div></div> <div class="chat chat-start"><div class="chat-image avatar"><div class="w-10 rounded-full"><img alt="Tailwind CSS chat bubble component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div> <div class="chat-bubble">It was you who would bring balance to the Force</div></div> <div class="chat chat-start"><div class="chat-image avatar"><div class="w-10 rounded-full"><img alt="Tailwind CSS chat bubble component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div> <div class="chat-bubble">Not leave it in Darkness</div></div>';return{c(){t=v("div"),t.innerHTML=l,this.h()},l(e){t=u(e,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-sgni99"&&(t.innerHTML=l),this.h()},h(){$(t,"class","w-full")},m(e,i){b(e,t,i)},p:I,d(e){e&&r(t)}}}function it(d){let t,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-image $$avatar">
    <div class="w-10 rounded-full">
      <img alt="Tailwind CSS chat bubble component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-bubble">It was said that you would, destroy the Sith, not join them.</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-image $$avatar">
    <div class="w-10 rounded-full">
      <img alt="Tailwind CSS chat bubble component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-bubble">It was you who would bring balance to the Force</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-image $$avatar">
    <div class="w-10 rounded-full">
      <img alt="Tailwind CSS chat bubble component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-bubble">Not leave it in Darkness</div>
</div>`,e,i,c,n;return{c(){t=v("pre"),e=j(l),this.h()},l(a){t=u(a,"PRE",{slot:!0});var o=M(t);e=D(o,l),o.forEach(r),this.h()},h(){$(t,"slot","html")},m(a,o){b(a,t,o),E(t,e),c||(n=A(i=L.call(null,t,{to:d[0]})),c=!0)},p(a,o){i&&H(i.update)&&o&1&&i.update.call(null,{to:a[0]})},d(a){a&&r(t),c=!1,n()}}}function ct(d){let t,l=`<div class="chat chat-start"><div class="chat-image avatar"><div class="w-10 rounded-full"><img alt="Tailwind CSS chat bubble component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div> <div class="chat-header">Obi-Wan Kenobi
      <time class="text-xs opacity-50">12:45</time></div> <div class="chat-bubble">You were the Chosen One!</div> <div class="chat-footer opacity-50">Delivered</div></div> <div class="chat chat-end"><div class="chat-image avatar"><div class="w-10 rounded-full"><img alt="Tailwind CSS chat bubble component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg"/></div></div> <div class="chat-header">Anakin
      <time class="text-xs opacity-50">12:46</time></div> <div class="chat-bubble">I hate you!</div> <div class="chat-footer opacity-50">Seen at 12:46</div></div>`;return{c(){t=v("div"),t.innerHTML=l,this.h()},l(e){t=u(e,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-11khduz"&&(t.innerHTML=l),this.h()},h(){$(t,"class","w-full")},m(e,i){b(e,t,i)},p:I,d(e){e&&r(t)}}}function lt(d){let t,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-image avatar">
    <div class="w-10 rounded-full">
      <img alt="Tailwind CSS chat bubble component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-header">
    Obi-Wan Kenobi
    <time class="text-xs opacity-50">12:45</time>
  </div>
  <div class="$$chat-bubble">You were the Chosen One!</div>
  <div class="$$chat-footer opacity-50">
    Delivered
  </div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-image avatar">
    <div class="w-10 rounded-full">
      <img alt="Tailwind CSS chat bubble component" src="/images/stock/photo-1534528741775-53994a69daeb.jpg" />
    </div>
  </div>
  <div class="$$chat-header">
    Anakin
    <time class="text-xs opacity-50">12:46</time>
  </div>
  <div class="$$chat-bubble">I hate you!</div>
  <div class="$$chat-footer opacity-50">
    Seen at 12:46
  </div>
</div>`,e,i,c,n;return{c(){t=v("pre"),e=j(l),this.h()},l(a){t=u(a,"PRE",{slot:!0});var o=M(t);e=D(o,l),o.forEach(r),this.h()},h(){$(t,"slot","html")},m(a,o){b(a,t,o),E(t,e),c||(n=A(i=L.call(null,t,{to:d[0]})),c=!0)},p(a,o){i&&H(i.update)&&o&1&&i.update.call(null,{to:a[0]})},d(a){a&&r(t),c=!1,n()}}}function ot(d){let t,l=`<div class="chat chat-start"><div class="chat-header">Obi-Wan Kenobi
      <time class="text-xs opacity-50">2 hours ago</time></div> <div class="chat-bubble">You were my brother, Anakin.</div> <div class="chat-footer opacity-50">Seen</div></div> <div class="chat chat-start"><div class="chat-header">Obi-Wan Kenobi
      <time class="text-xs opacity-50">2 hour ago</time></div> <div class="chat-bubble">I loved you.</div> <div class="chat-footer opacity-50">Delivered</div></div>`;return{c(){t=v("div"),t.innerHTML=l,this.h()},l(e){t=u(e,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-1eihov2"&&(t.innerHTML=l),this.h()},h(){$(t,"class","w-full")},m(e,i){b(e,t,i)},p:I,d(e){e&&r(t)}}}function dt(d){let t,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-header">
    Obi-Wan Kenobi
    <time class="text-xs opacity-50">2 hours ago</time>
  </div>
  <div class="$$chat-bubble">You were the Chosen One!</div>
  <div class="$$chat-footer opacity-50">
    Seen
  </div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-header">
    Obi-Wan Kenobi
    <time class="text-xs opacity-50">2 hour ago</time>
  </div>
  <div class="$$chat-bubble">I loved you.</div>
  <div class="$$chat-footer opacity-50">
    Delivered
  </div>
</div>`,e,i,c,n;return{c(){t=v("pre"),e=j(l),this.h()},l(a){t=u(a,"PRE",{slot:!0});var o=M(t);e=D(o,l),o.forEach(r),this.h()},h(){$(t,"slot","html")},m(a,o){b(a,t,o),E(t,e),c||(n=A(i=L.call(null,t,{to:d[0]})),c=!0)},p(a,o){i&&H(i.update)&&o&1&&i.update.call(null,{to:a[0]})},d(a){a&&r(t),c=!1,n()}}}function nt(d){let t,l='<div class="chat chat-start"><div class="chat-bubble chat-bubble-primary">What kind of nonsense is this</div></div> <div class="chat chat-start"><div class="chat-bubble chat-bubble-secondary">Put me on the Council and not make me a Master!??</div></div> <div class="chat chat-start"><div class="chat-bubble chat-bubble-accent">That&#39;s never been done in the history of the Jedi. It&#39;s insulting!</div></div> <div class="chat chat-end"><div class="chat-bubble chat-bubble-info">Calm down, Anakin.</div></div> <div class="chat chat-end"><div class="chat-bubble chat-bubble-success">You have been given a great honor.</div></div> <div class="chat chat-end"><div class="chat-bubble chat-bubble-warning">To be on the Council at your age.</div></div> <div class="chat chat-end"><div class="chat-bubble chat-bubble-error">It&#39;s never happened before.</div></div>';return{c(){t=v("div"),t.innerHTML=l,this.h()},l(e){t=u(e,"DIV",{class:!0,"data-svelte-h":!0}),T(t)!=="svelte-6tnx1"&&(t.innerHTML=l),this.h()},h(){$(t,"class","w-full")},m(e,i){b(e,t,i)},p:I,d(e){e&&r(t)}}}function ht(d){let t,l=`<div class="$$chat $$chat-start">
  <div class="$$chat-bubble $$chat-bubble-primary">What kind of nonsense is this</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-bubble $$chat-bubble-secondary">Put me on the Council and not make me a Master!??</div>
</div>
<div class="$$chat $$chat-start">
  <div class="$$chat-bubble $$chat-bubble-accent">That's never been done in the history of the Jedi. It's insulting!</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-info">Calm down, Anakin.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-success">You have been given a great honor.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-warning">To be on the Council at your age.</div>
</div>
<div class="$$chat $$chat-end">
  <div class="$$chat-bubble $$chat-bubble-error">It's never happened before.</div>
</div>`,e,i,c,n;return{c(){t=v("pre"),e=j(l),this.h()},l(a){t=u(a,"PRE",{slot:!0});var o=M(t);e=D(o,l),o.forEach(r),this.h()},h(){$(t,"slot","html")},m(a,o){b(a,t,o),E(t,e),c||(n=A(i=L.call(null,t,{to:d[0]})),c=!0)},p(a,o){i&&H(i.update)&&o&1&&i.update.call(null,{to:a[0]})},d(a){a&&r(t),c=!1,n()}}}function rt(d){let t,l,e,i,c,n,a,o,m,O,p,P;return t=new tt({props:{data:[{type:"component",class:"chat",desc:"Container for one line of conversation and all its data"},{type:"modifier",class:"chat-start",desc:"Aligns `chat` to left (required)"},{type:"modifier",class:"chat-end",desc:"Aligns `chat` to end (required)"},{type:"component",class:"chat-image",desc:"For the author image"},{type:"component",class:"chat-header",desc:"For the line above the chat bubble"},{type:"component",class:"chat-footer",desc:"For the line below the chat bubble"},{type:"component",class:"chat-bubble",desc:"For the content of chat"},{type:"modifier",class:"chat-bubble-primary",desc:"sets `primary` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-secondary",desc:"sets `secondary` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-accent",desc:"sets `accent` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-info",desc:"sets `info` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-success",desc:"sets `success` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-warning",desc:"sets `warning` color for the `chat-bubble`"},{type:"modifier",class:"chat-bubble-error",desc:"sets `error` color for the `chat-bubble`"}]}}),e=new k({props:{title:"chat-start and chat-end",$$slots:{html:[at],default:[et]},$$scope:{ctx:d}}}),c=new k({props:{title:"Chat with image",$$slots:{html:[it],default:[st]},$$scope:{ctx:d}}}),a=new k({props:{title:"Chat with image, header and footer",$$slots:{html:[lt],default:[ct]},$$scope:{ctx:d}}}),m=new k({props:{title:"Chat with header and footer",$$slots:{html:[dt],default:[ot]},$$scope:{ctx:d}}}),p=new k({props:{title:"Chat Bubble with colors",$$slots:{html:[ht],default:[nt]},$$scope:{ctx:d}}}),{c(){f(t.$$.fragment),l=x(),f(e.$$.fragment),i=x(),f(c.$$.fragment),n=x(),f(a.$$.fragment),o=x(),f(m.$$.fragment),O=x(),f(p.$$.fragment)},l(s){g(t.$$.fragment,s),l=S(s),g(e.$$.fragment,s),i=S(s),g(c.$$.fragment,s),n=S(s),g(a.$$.fragment,s),o=S(s),g(m.$$.fragment,s),O=S(s),g(p.$$.fragment,s)},m(s,h){_(t,s,h),b(s,l,h),_(e,s,h),b(s,i,h),_(c,s,h),b(s,n,h),_(a,s,h),b(s,o,h),_(m,s,h),b(s,O,h),_(p,s,h),P=!0},p(s,h){const Y={};h&5&&(Y.$$scope={dirty:h,ctx:s}),e.$set(Y);const F={};h&5&&(F.$$scope={dirty:h,ctx:s}),c.$set(F);const K={};h&5&&(K.$$scope={dirty:h,ctx:s}),a.$set(K);const R={};h&5&&(R.$$scope={dirty:h,ctx:s}),m.$set(R);const V={};h&5&&(V.$$scope={dirty:h,ctx:s}),p.$set(V)},i(s){P||(w(t.$$.fragment,s),w(e.$$.fragment,s),w(c.$$.fragment,s),w(a.$$.fragment,s),w(m.$$.fragment,s),w(p.$$.fragment,s),P=!0)},o(s){y(t.$$.fragment,s),y(e.$$.fragment,s),y(c.$$.fragment,s),y(a.$$.fragment,s),y(m.$$.fragment,s),y(p.$$.fragment,s),P=!1},d(s){s&&(r(l),r(i),r(n),r(o),r(O)),C(t,s),C(e,s),C(c,s),C(a,s),C(m,s),C(p,s)}}}function bt(d){let t,l;const e=[d[1],J];let i={$$slots:{default:[rt]},$$scope:{ctx:d}};for(let c=0;c<e.length;c+=1)i=W(i,e[c]);return t=new X({props:i}),{c(){f(t.$$.fragment)},l(c){g(t.$$.fragment,c)},m(c,n){_(t,c,n),l=!0},p(c,[n]){const a=n&2?U(e,[n&2&&z(c[1]),n&0&&z(J)]):{};n&5&&(a.$$scope={dirty:n,ctx:c}),t.$set(a)},i(c){l||(w(t.$$.fragment,c),l=!0)},o(c){y(t.$$.fragment,c),l=!1},d(c){C(t,c)}}}const J={title:"Chat bubble",desc:"Chat bubbles are used to show one line of conversation and all its data, including the author image, author name, time, etc.",published:!0,layout:"components"};function vt(d,t,l){let e;return B(d,Z,i=>l(0,e=i)),d.$$set=i=>{l(1,t=W(W({},t),q(i)))},t=q(t),[e,t]}class _t extends G{constructor(t){super(),Q(this,t,vt,bt,N,{})}}export{_t as component};
